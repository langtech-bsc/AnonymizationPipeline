#!/bin/bash

# INPUT
# File that contains the annotations of the sensitive data in JSONL format

python substitution_of_sensitive_data.py -f ../vol1/$1 -o ../vol1/
