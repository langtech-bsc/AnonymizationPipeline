#!/bin/bash

# INPUT:
# Folder that contains the original data to be anonymized (will also be used for the output)
# File inside the specified folder that has the data to be treated

# PROCESS:
#---------
# Regex over original text and generate brat output
# Convert brat to conll 
# Execute Name identification over the conll and generate a new conll (only change the labels)


#Run the identification of regular expressions (Telephones, Bank accounts, Identification numbers, E-mail addresses, credit cards, etc)
python regular_identification.py -f ../vol1/$1

#Copy the original text to the folder in which the BRAT result of the previous step is located so that we can transform the BRAT into CONLL
cp ../vol1/$1 output/tmp/regular_identification.txt

#Transform the result of the regular expression identification from BRAT format to CONLL format with added span information
python brat_to_conll.py -i output/tmp/ -o output/text_brat_to_conll.conll

#Run the identification of common names in Spain (from list of names)
python name_identification.py 

#Copy the suggestion conll file to the directory that contains the original text
cp output/suggestion.conll ../vol1/suggestion.txt


